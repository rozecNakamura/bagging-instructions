/**
 * 現品票印刷：マスタ読込・検索・結果表示（明細行・チェック選択）
 */
import {
    fetchMajorClassifications,
    fetchProductLabelMiddleClassifications,
    fetchProductLabelWorkcenters,
    fetchProductLabelWarehouses,
    searchProductLabel,
    filterProductLabelByChild,
    fetchProductionInstructionSlots,
    searchProductionInstruction,
} from './api.js';


let productLabelRows = [];
let plSlotList = [];
let plSelectedSlotCodes = new Set();

function formatDateYyyymmdd(yyyymmdd) {
    if (!yyyymmdd || yyyymmdd.length !== 8) return yyyymmdd || '-';
    return `${yyyymmdd.slice(0, 4)}-${yyyymmdd.slice(4, 6)}-${yyyymmdd.slice(6, 8)}`;
}

/** マスタ一覧を1回だけ取得し、指定した複数の select に同じ選択肢を流し込む。 */
async function loadSelect(selectIds, fetcher, labelFn, errorText) {
    const ids = Array.isArray(selectIds) ? selectIds : [selectIds];
    const sels = ids.map(id => document.getElementById(id)).filter(Boolean);
    if (sels.length === 0) return;
    try {
        const list = await fetcher();
        for (const sel of sels) {
            sel.innerHTML = '';
            const empty = document.createElement('option');
            empty.value = '';
            empty.textContent = '指定なし（すべて）';
            sel.appendChild(empty);
            for (const item of list) {
                const opt = document.createElement('option');
                opt.value = String(item.id);
                opt.dataset.code = item.code || '';
                opt.textContent = labelFn(item);
                sel.appendChild(opt);
            }
        }
    } catch (e) {
        for (const sel of sels) sel.innerHTML = `<option value="">${errorText}</option>`;
        console.error(e);
    }
}

async function loadMajorClassifications() {
    await loadSelect(
        ['productLabelMajorClass', 'productLabelChildMajorClass'],
        fetchMajorClassifications,
        (m) => (`${m.code ? m.code + ' ' : ''}${m.name || ''}`).trim() || String(m.id),
        '大分類の取得に失敗しました'
    );
}

/** 子品目の中分類：子品目大分類が選択されていればその配下のみ、未選択なら全件。 */
async function loadChildMiddleClassifications(majorId) {
    await loadSelect(
        'productLabelChildMiddleClass',
        () => fetchProductLabelMiddleClassifications(majorId || undefined),
        (m) => (`${m.code ? m.code + ' ' : ''}${m.name || ''}`).trim() || String(m.id),
        '中分類の取得に失敗しました'
    );
}

async function loadWorkcenters() {
    await loadSelect(
        'productLabelWorkcenter',
        fetchProductLabelWorkcenters,
        (w) => w.name || String(w.id),
        '作業区の取得に失敗しました'
    );
}

async function loadWarehouses() {
    await loadSelect(
        ['productLabelWarehouse', 'productLabelChildWarehouse'],
        fetchProductLabelWarehouses,
        (w) => `${w.code ? w.code + ' ' : ''}${w.name || ''}`.trim() || String(w.id),
        '倉庫の取得に失敗しました'
    );
}

function isSeasoningSelected() {
    const sel = document.getElementById('productLabelMajorClass');
    if (!sel) return false;
    const opt = sel.options[sel.selectedIndex];
    return opt ? (opt.dataset.code || '').startsWith('55') : false;
}

function updatePlSlotLabel() {
    const label = document.getElementById('productLabelSlotSelectedLabel');
    if (!label) return;
    const total = plSlotList.length;
    const sel = plSelectedSlotCodes.size;
    if (total === 0 || sel === 0) {
        label.textContent = 'すべて';
    } else if (sel === total) {
        label.textContent = 'すべて';
    } else {
        label.textContent = `${sel}件選択`;
    }
}

function buildPlSlotPanel() {
    const container = document.getElementById('productLabelSlotOptions');
    if (!container) return;
    container.innerHTML = '';
    plSlotList.forEach(s => {
        const lbl = document.createElement('label');
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.value = s.code || '';
        if (plSelectedSlotCodes.has(s.code)) cb.checked = true;
        cb.addEventListener('change', () => {
            if (cb.checked) {
                if (s.code) plSelectedSlotCodes.add(s.code);
            } else {
                plSelectedSlotCodes.delete(s.code);
            }
            updatePlSlotLabel();
        });
        const text = document.createElement('span');
        text.textContent = s.name || s.code || '';
        lbl.appendChild(cb);
        lbl.appendChild(text);
        container.appendChild(lbl);
    });
    updatePlSlotLabel();
}

async function loadPlSlots(needDate) {
    plSelectedSlotCodes = new Set();
    plSlotList = [];
    const container = document.getElementById('productLabelSlotOptions');
    if (container) container.innerHTML = '';
    if (!needDate) {
        updatePlSlotLabel();
        return;
    }
    try {
        plSlotList = await fetchProductionInstructionSlots(needDate) || [];
        buildPlSlotPanel();
    } catch (e) {
        console.error('現品票 便一覧取得エラー:', e);
        updatePlSlotLabel();
    }
}

function setAllProductLabelCheckboxes(checked) {
    document.querySelectorAll('.product-label-row-check').forEach((el) => { el.checked = checked; });
}

/** 子品目の検索条件をまとめて取得。 */
function getChildConditions() {
    return {
        childItemCode: document.getElementById('productLabelChildItemCode')?.value || undefined,
        childMajorClassificationId: document.getElementById('productLabelChildMajorClass')?.value || undefined,
        childMiddleClassificationId: document.getElementById('productLabelChildMiddleClass')?.value || undefined,
        childWarehouseId: document.getElementById('productLabelChildWarehouse')?.value || undefined,
    };
}

function hasChildConditions(cond) {
    return Object.values(cond).some(v => v != null && String(v).trim() !== '');
}

document.getElementById('productLabelSearchBtn').addEventListener('click', async () => {
    const needDate = document.getElementById('productLabelNeedDate').value;
    if (!needDate) { alert('納期を入力してください'); return; }

    const childCond = getChildConditions();

    if (isSeasoningSelected()) {
        const slotCodes = Array.from(plSelectedSlotCodes);
        try {
            const res = await searchProductionInstruction(needDate, [], slotCodes);
            let rows = res.rows || [];

            // 調味液配合表ルートは製造指示書検索を使うため、子品目条件はサーバへ後掛けで問い合わせて絞り込む
            if (rows.length > 0 && hasChildConditions(childCond)) {
                const matched = await filterProductLabelByChild({
                    itemCodes: rows.map(r => r.itemCode).filter(Boolean),
                    ...childCond,
                });
                const allowed = new Set(matched);
                rows = rows.filter(r => allowed.has((r.itemCode || '').trim()));
            }

            productLabelRows = rows.map(r => ({
                order_table_ids: [r.orderTableId],
                release_date: r.needDate,
                item_code: r.itemCode,
                item_name: r.itemName,
                child_count: null,
                qty: r.quantityDisplay != null ? `${r.quantityDisplay}${r.unitName ? ' ' + r.unitName : ''}`.trim() : null,
                workcenter_name: '',
            }));
            displayProductLabelResults(productLabelRows);
        } catch (error) {
            alert('検索に失敗しました: ' + error.message);
        }
        return;
    }

    const majorId = document.getElementById('productLabelMajorClass')?.value;
    const itemCode = document.getElementById('productLabelItemCode')?.value;
    const workcenterId = document.getElementById('productLabelWorkcenter')?.value;
    const warehouseId = document.getElementById('productLabelWarehouse')?.value;

    try {
        const res = await searchProductLabel({
            needDate,
            majorClassificationId: majorId || undefined,
            itemCode: itemCode || undefined,
            workcenterId: workcenterId || undefined,
            warehouseId: warehouseId || undefined,
            ...childCond,
        });
        productLabelRows = res.rows || [];
        displayProductLabelResults(productLabelRows);
    } catch (error) {
        alert('検索に失敗しました: ' + error.message);
    }
});

const productLabelSelectAll = document.getElementById('productLabelSelectAll');
if (productLabelSelectAll) {
    productLabelSelectAll.addEventListener('change', () => {
        setAllProductLabelCheckboxes(productLabelSelectAll.checked);
    });
}

function displayProductLabelResults(rows) {
    const section = document.getElementById('productLabelResultsSection');
    const printSection = document.getElementById('productLabelPrintSection');
    const countEl = document.getElementById('productLabelResultCount');
    const tbody = document.getElementById('productLabelResultsBody');

    if (rows.length === 0) {
        alert('該当するデータが見つかりませんでした');
        section.style.display = 'none';
        printSection.style.display = 'none';
        return;
    }

    countEl.textContent = `${rows.length}件`;
    tbody.innerHTML = '';

    rows.forEach((row) => {
        const tr = tbody.insertRow();
        const rowIds = row.order_table_ids || [];
        const firstId = rowIds[0] || 0;

        const tdCb = tr.insertCell();
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'product-label-row-check';
        cb.checked = true;
        cb.dataset.orderTableIds = JSON.stringify(rowIds);
        cb.dataset.orderTableId = String(firstId);
        tdCb.appendChild(cb);

        const idDisplay = rowIds.length <= 1 ? (firstId > 0 ? String(firstId) : '-') : `合算(${rowIds.length}件)`;
        tr.insertCell().textContent = idDisplay;
        tr.insertCell().textContent = formatDateYyyymmdd(row.release_date) || '-';
        tr.insertCell().textContent = row.item_code || '-';
        tr.insertCell().textContent = row.item_name || '-';
        tr.insertCell().textContent = row.child_count != null ? String(row.child_count) : '-';
        tr.insertCell().textContent = row.qty != null ? String(row.qty) : '-';
        tr.insertCell().textContent = row.workcenter_name || '-';

        const tdCount = tr.insertCell();
        const countInput = document.createElement('input');
        countInput.type = 'number';
        countInput.min = '1';
        countInput.max = '99';
        countInput.value = '1';
        countInput.style.cssText = 'width:55px;padding:2px 4px;';
        countInput.className = 'product-label-row-count';
        countInput.dataset.orderTableId = String(firstId);
        tdCount.appendChild(countInput);
    });

    if (productLabelSelectAll) productLabelSelectAll.checked = true;

    section.style.display = 'block';
    printSection.style.display = 'flex';
}

document.addEventListener('DOMContentLoaded', () => {
    loadMajorClassifications();
    loadChildMiddleClassifications('');
    loadWorkcenters();
    loadWarehouses();

    // 子品目大分類を変えたら中分類を絞り直す（選択済み中分類はクリア）
    const childMajorSel = document.getElementById('productLabelChildMajorClass');
    childMajorSel?.addEventListener('change', () => {
        loadChildMiddleClassifications(childMajorSel.value || '');
    });

    const plNeedDateInput = document.getElementById('productLabelNeedDate');
    const onPlNeedDateChanged = () => loadPlSlots(plNeedDateInput?.value || '');
    plNeedDateInput?.addEventListener('change', onPlNeedDateChanged);
    plNeedDateInput?.addEventListener('input', onPlNeedDateChanged);
    if (plNeedDateInput?.value) {
        loadPlSlots(plNeedDateInput.value);
    }

    const slotDisplay = document.getElementById('productLabelSlotDisplay');
    if (slotDisplay) {
        slotDisplay.addEventListener('click', (e) => {
            e.stopPropagation();
            const panel = document.getElementById('productLabelSlotOptions');
            if (!panel) return;
            const isHidden = panel.style.display === 'none' || panel.style.display === '';
            panel.style.display = isHidden ? 'block' : 'none';
        });
    }

    document.addEventListener('click', (e) => {
        const dropdown = (e.target instanceof HTMLElement)
            ? e.target.closest('#screen-product-label .multi-select-dropdown')
            : null;
        if (!dropdown) {
            const panel = document.getElementById('productLabelSlotOptions');
            if (panel) panel.style.display = 'none';
        }
    });
});

/** 印刷用：選択された ordertableid の全リスト（合算行は複数 ID を展開）。*/
export function getSelectedProductLabelOrderTableIds() {
    const ids = [];
    document.querySelectorAll('.product-label-row-check:checked').forEach((el) => {
        let rowIds;
        try { rowIds = JSON.parse(el.dataset.orderTableIds || '[]'); } catch { rowIds = []; }
        rowIds.forEach(id => { if (id > 0) ids.push(id); });
    });
    return ids;
}

/** 印刷用：選択された {ids, count} の配列（行ごとの枚数を含む）。ids は合算元の全 ordertableid。*/
export function getSelectedProductLabelItems() {
    const items = [];
    document.querySelectorAll('.product-label-row-check:checked').forEach((el) => {
        let rowIds;
        try { rowIds = JSON.parse(el.dataset.orderTableIds || '[]').filter(id => id > 0); } catch { rowIds = []; }
        if (!rowIds.length) return;
        const firstId = rowIds[0];
        const countEl = document.querySelector(`.product-label-row-count[data-order-table-id="${firstId}"]`);
        const count = countEl ? Math.max(1, parseInt(countEl.value, 10) || 1) : 1;
        items.push({ ids: rowIds, count });
    });
    return items;
}
